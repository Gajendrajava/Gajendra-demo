package EmployeeManagementSystemProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnSignup;

    public LoginFrame() {
        setTitle("Login - Employee Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel("Login", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblTitle.setBounds(100, 20, 200, 30);
        add(lblTitle);
        
        JLabel Txt = new JLabel("Not registered? create ab account");
      
        Txt .setBounds(80, 200, 300, 30);
        add(Txt );

        addLabel("Username:", 80);
        txtUsername = addTextField(80);

        addLabel("Password:", 120);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 120, 150, 25);
        add(txtPassword);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(150, 180, 80, 30);
        btnLogin.setBackground(new Color(0, 123, 255));
        btnLogin.setForeground(Color.WHITE);
        add(btnLogin);

        btnSignup = new JButton("Signup");
        btnSignup.setBounds(100, 250, 100, 30);
        add(btnSignup);

        btnLogin.addActionListener(e -> loginUser());
        btnSignup.addActionListener(e -> {
            new SignupFrame().setVisible(true);
           // dispose();
        });
    }

    private void addLabel(String text, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(50, y, 100, 25);
        add(lbl);
    }

    private JTextField addTextField(int y) {
        JTextField field = new JTextField();
        field.setBounds(150, y, 150, 25);
        add(field);
        return field;
    }

    private void loginUser() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeemanagement", "root", "");

            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, txtUsername.getText());
            pst.setString(2, new String(txtPassword.getPassword()));

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
               new modified_Home1().setVisible(true);  // your dashboard
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password!");
            }

            rs.close();
            pst.close();
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new LoginFrame().setVisible(true);
    }
}
