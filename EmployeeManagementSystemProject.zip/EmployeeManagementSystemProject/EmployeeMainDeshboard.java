package EmployeeManagementSystemProject;

	import javax.swing.*;
	import java.awt.*;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	public class EmployeeMainDeshboard  extends JFrame {

	    // Declare panels
	    JPanel sidebar, mainPanel, cardPanel;
	    CardLayout cardLayout;

	    public EmployeeMainDeshboard () {
	        // Frame settings
	        setTitle("Employee Management System");
	        setSize(1600, 800);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setLocationRelativeTo(null);
	        setLayout(new BorderLayout());

	        // Sidebar Panel
	        sidebar = new JPanel();
	        sidebar.setBackground(new Color(60, 63, 65));
	        sidebar.setPreferredSize(new Dimension(200, getHeight()));
	        sidebar.setLayout(new GridLayout(5, 1)); //wedth fir length

	        // Buttons for navigation
	        String[] buttons = {"Empolyee", "add Employee","Department", "Attendense", "Logout"};
	        for (String name : buttons) {
	            JButton btn = new JButton(name);
	            btn.setFocusPainted(false);
	            btn.setBackground(Color.DARK_GRAY);
	            btn.setForeground(Color.WHITE);
	            
	            btn.addActionListener(new SidebarActionListener());
	            sidebar.add(btn);
	        }

	        // Main Panel with CardLayout
	        cardLayout = new CardLayout();
	        cardPanel = new JPanel(cardLayout);

	        // Add different cards
	        cardPanel.add(createLabelPanel("Welcome to Home Page"), "Add Empolyee");
	        cardPanel.add(createLabelPanel("User Profile Page"), "View Employee");
	        cardPanel.add(createLabelPanel("Application Settings Page"), "Salary Management");
	        cardPanel.add(createLabelPanel(" Application details"), "Attendense");
	        cardPanel.add(createLabelPanel("You are logged out"), "Logout");

	        // Add panels to frame
	        add(sidebar, BorderLayout.WEST);
	        add(cardPanel, BorderLayout.CENTER);

	        setVisible(true);
	    }

	    // Create a simple panel with a label
	    private JPanel createLabelPanel(String text) {
	        JPanel panel = new JPanel();
	        JLabel label = new JLabel(text);
	        JTextField tf=new JTextField();
	        
	        label.setFont(new Font("Arial", Font.BOLD, 24));
	        panel.add(label);
	        return panel;
	    }

	    // Action listener for sidebar buttons
	    private class SidebarActionListener implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            JButton source = (JButton) e.getSource();
	            cardLayout.show(cardPanel, source.getText());
	        }
	    }

	    public static void main(String[] args) {
	        SwingUtilities.invokeLater(() -> new EmployeeMainDeshboard ());
	    }
	}


