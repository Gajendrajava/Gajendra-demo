package EmployeeManagementSystemProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SignupFrame extends JFrame {

    private JTextField txtName, txtEmail, txtContact, txtAddress, txtUsername;
    private JPasswordField txtPassword;
    private JButton btnSignup, btnLogin;

    public SignupFrame() {
        setTitle("Signup - Employee Management System");
        setSize(400, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel("Create New Account", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitle.setBounds(80, 20, 250, 30);
        add(lblTitle);

        addLabel("Full Name:", 50);
        txtName = addTextField(50);

        addLabel("Email:", 90);
        txtEmail = addTextField(90);

        addLabel("Contact:", 130);
        txtContact = addTextField(130);

        addLabel("Address:", 170);
        txtAddress = addTextField(170);

        addLabel("Username:", 210);
        txtUsername = addTextField(210);

        addLabel("Password:", 250);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 250, 180, 25);
        add(txtPassword);

        btnSignup = new JButton("Sign Up");
        btnSignup.setBounds(80, 300, 100, 30);
        btnSignup.setBackground(new Color(0, 123, 255));
        btnSignup.setForeground(Color.WHITE);
        add(btnSignup);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(200, 300, 100, 30);
        add(btnLogin);

        btnSignup.addActionListener(e -> signupUser());
        btnLogin.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
    }

    private void addLabel(String text, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(50, y, 100, 25);
        add(lbl);
    }

    private JTextField addTextField(int y) {
        JTextField field = new JTextField();
        field.setBounds(150, y, 180, 25);
        add(field);
        return field;
    }

    private void signupUser() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/employeemanagement", "root", "");

            String sql = "INSERT INTO users (name, email, contact, address, username, password) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, txtName.getText());
            pst.setString(2, txtEmail.getText());
            pst.setString(3, txtContact.getText());
            pst.setString(4, txtAddress.getText());
            pst.setString(5, txtUsername.getText());
            pst.setString(6, new String(txtPassword.getPassword()));

            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Signup Successful! Now Login.");
                new LoginFrame().setVisible(true);
                dispose();
            }

            pst.close();
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new SignupFrame().setVisible(true);
    }
}
